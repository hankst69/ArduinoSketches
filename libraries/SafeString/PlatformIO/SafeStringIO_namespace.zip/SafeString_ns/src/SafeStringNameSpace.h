#ifndef SAFE_STRING_NAMESPACE_H
#define SAFE_STRING_NAMESPACE_H
//#include "SafeStringNameSpace.h"

// for PlatformIO for boards that DO use namespace arduino in Print.h
using namespace arduino;

#endif