#ifndef SAFE_STRING_NAMESPACE_END_H
#define SAFE_STRING_NAMESPACE_END_H

// for PlatformIO for boards that DO use namespace arduino in Print.h
} // namespace arduino

#endif
