
This directory is intended for the project specific (private) libraries.
