#include <stdint.h>

struct HVACIcons{
   static uint8_t house[8];
   static uint8_t ventilator8x8[8];
   static uint8_t ventilator16x16_1of2[16];
   static uint8_t ventilator16x16_2of2[16];
};
