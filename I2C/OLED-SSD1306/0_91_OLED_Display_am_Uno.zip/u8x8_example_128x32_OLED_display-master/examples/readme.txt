* examples -- a folder with examples, of how to:
	- debounce a momentary button in an interrupt
	- debounce a momentary button in main loop
	- using an alternative of the delay() function, how all we know it pauses the code in main loop by using an interrupt routine
